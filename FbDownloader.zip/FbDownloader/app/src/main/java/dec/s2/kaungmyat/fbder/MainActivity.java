package dec.s2.kaungmyat.fbder;
 
import android.app.*;
import android.os.*;
import android.webkit.*;
import java.io.*;
import android.net.*;
import android.widget.*;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Color;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.content.Context;

public class MainActivity extends Activity 
{
     String target_url = "https://m.facebook.com/";
    private static WebView webView;
    LinearLayout more_layout;
    ImageButton imb;
    int currentP=0;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); 
        webView = (WebView)findViewById(R.id.wv);
        // Check for the internet connection available or not
        if(isConnectingToInternet()) {
loadWeb(target_url);
            
        }else {
            webView.loadUrl("file:///android_asset/dance.html");
        }
        
        more_layout=findViewById(R.id.more_layout);
        imb=findViewById(R.id.more);
        more_layout.setVisibility(View.INVISIBLE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(this, "FBDownloader");

        webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    webView.loadUrl("javascript:(function() { "
                                    + "var el = document.querySelectorAll('div[data-sigil]');"
                                    + "for(var i=0;i<el.length; i++)"
                                    + "{"
                                    + "var sigil = el[i].dataset.sigil;"
                                    + "if(sigil.indexOf('inlineVideo') > -1){"
                                    + "delete el[i].dataset.sigil;"
                                    + "var jsonData = JSON.parse(el[i].dataset.store);"
                                    + "el[i].setAttribute('onClick', 'FBDownloader.processVideo(\"'+jsonData['src']+'\");');"
                                    + "}" + "}" + "})()");
                }

                @Override
                public void onLoadResource(WebView view, String url) {
                    webView.loadUrl("javascript:(function prepareVideo() { "
                                    + "var el = document.querySelectorAll('div[data-sigil]');"
                                    + "for(var i=0;i<el.length; i++)"
                                    + "{"
                                    + "var sigil = el[i].dataset.sigil;"
                                    + "if(sigil.indexOf('inlineVideo') > -1){"
                                    + "delete el[i].dataset.sigil;"
                                    + "console.log(i);"
                                    + "var jsonData = JSON.parse(el[i].dataset.store);"
                                    + "el[i].setAttribute('onClick', 'FBDownloader.processVideo(\"'+jsonData['src']+'\",\"'+jsonData['videoID']+'\");');"
                                    + "}" + "}" + "})()");
                    webView.loadUrl("javascript:( window.onload=prepareVideo;"
                                    + ")()");
                }
            });
        CookieSyncManager.createInstance(this);
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        CookieSyncManager.getInstance().startSync();
        
    }
private void loadWeb(String link){
    webView.getSettings().setJavaScriptEnabled(true);
    webView.getSettings().setDisplayZoomControls(false);
    webView.getSettings().setSupportZoom(true);
    webView.getSettings().setBuiltInZoomControls(false);
    webView.getSettings().setLoadWithOverviewMode(true);
    webView.getSettings().setUseWideViewPort(true);
    webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
    webView.setScrollbarFadingEnabled(false);
    webView.loadUrl(link);
}
    @JavascriptInterface
    public void processVideo(final String vidData, final String vidID) {
        try {
            String mBaseFolderPath = android.os.Environment
                .getExternalStorageDirectory()
                + File.separator
                + "Fb Videos" + File.separator;
            if (!new File(mBaseFolderPath).exists()) {
                new File(mBaseFolderPath).mkdir();
            }
            String mFilePath = "file://" + mBaseFolderPath + "/" + vidID + ".mp4";

            Uri downloadUri = Uri.parse(vidData);
           final DownloadManager.Request req = new DownloadManager.Request(downloadUri);
            req.setDestinationUri(Uri.parse(mFilePath));
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
          final  DownloadManager dm = (DownloadManager) getSystemService(getApplicationContext().DOWNLOAD_SERVICE);
         final AlertDialog alert=new AlertDialog.Builder(this).create();
         alert.setTitle("Download");
         alert.setIcon(R.drawable.ic_download);
         alert.setMessage("Are you sure to download video?");
            alert.setButton("Download", new DialogInterface.OnClickListener(){

            @Override                        
        public void onClick(DialogInterface p1, int p2)
            {                       
                dm.enqueue(req);
                Toast.makeText(getApplicationContext(),"Starting Download", Toast.LENGTH_LONG).show();
        }
    });
            alert.setButton2("No", new DialogInterface.OnClickListener(){

                    @Override                        
                    public void onClick(DialogInterface p1, int p2)
                    {                       
                        alert.dismiss();
                    }
                });
                alert.show();
            
        } catch (Exception e) {
            Toast.makeText(this,"Something Wrong!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed()
    {
        if(isConnectingToInternet()) {
            if (webView.canGoBack()) {
                webView.goBack();

            } else{ExitDia();
            }

        }else {
            ExitDia();
        }
        
    
    }
    private void ExitDia(){
        final AlertDialog  ad=new AlertDialog.Builder(this).create();
        ad.setTitle( "Exit" );
        ad.setIcon(R.drawable.ic_exit);
        ad.setMessage("Are you sure to Exit?");



        ad.setButton( AlertDialog.BUTTON_POSITIVE, "No", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface 
                                    p1, int p2) { 
                    p1.cancel();
                }
            });
        ad.setButton( AlertDialog.BUTTON_NEGATIVE, "Exit", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface 
                                    p1, int p2) { 
                    finish();
                    p1.cancel();
                }
            });




        ad.show();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        menu.add("insert")
            .setIcon(R.drawable.ic_link)
            .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        menu.add("reflash")
            .setIcon(R.drawable.reflash)
            .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if(item.getTitle()=="insert"){
            InsertUrl();
        }else
        if(item.getTitle()=="reflash"){
            loadWeb(target_url);
        }
        return super.onOptionsItemSelected(item);
    }
    private void InsertUrl(){
        final AlertDialog ad;
        AlertDialog.Builder adb;

        View v=getLayoutInflater().inflate(
            R.layout.insert_url_layout,null);
        final EditText etnew=(EditText)v.findViewById(R.id.et);

        adb=new AlertDialog.Builder(this);
        adb.setTitle( "Url" );
        adb.setIcon(R.drawable.ic_link);
     
        adb.setView(v);

        ad=adb.create();
        ad.setButton( AlertDialog.BUTTON_NEUTRAL, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface 
                                    p1, int p2) { 
                    p1.cancel();
                }
            });

        ad.setButton( AlertDialog.BUTTON_POSITIVE, "Done", new DialogInterface.OnClickListener() { 
                public void onClick(DialogInterface p1, int p2) {
         
                  String  url=etnew.getText().toString();
                    if(target_url!=null && target_url.startsWith("http") && target_url.contains("facebook")){
                        // Check for the internet connection available or not
                        if(isConnectingToInternet()) {
                            loadWeb(url);
							Toast.makeText(getApplicationContext(),url, Toast.LENGTH_LONG).show();
                        }else {
                            webView.loadUrl("file:///android_asset/dance.html");
                        }
                    }else{
                        Toast.makeText(getApplicationContext(),"Url is not facebook vide link!", Toast.LENGTH_LONG).show();
                    }
              
                    
                    p1.cancel();
                }
            });
        ad.show();
    }
    public void more(View v){
        if(currentP==0){
            more_layout.setVisibility(View.VISIBLE);
            imb.setImageResource(R.drawable.ic_cancel);
            currentP++;
        }else{
            more_layout.setVisibility(View.INVISIBLE);
            imb.setImageResource(R.drawable.ic_add);
            currentP=0;
        }
          
    }
    public void url(View v){
        InsertUrl();
    }
    
    
    public void about(View v){
        final AlertDialog ad;
        
        
        ad=new AlertDialog.Builder(this).create();
        ad.setTitle( "About" );
        ad.setIcon(R.drawable.ic_develop);
        ad.setMessage("This app is developed by Mg Kaung Myat(DEC).\n #Open source code\n Please Subscribe My Channel(@youtube.com/TechKipon).\n Thanks for everyone.");
      

        
        ad.setButton( AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface 
                                    p1, int p2) { 
                    Toast.makeText(getApplicationContext(),"Thanks you", Toast.LENGTH_LONG).show();
                    p1.cancel();
                }
            });


        ad.show();
    }
    public void reflash(View v){
        loadWeb(target_url);
    }
    public void exit(View v){
        ExitDia();
    }
    // Check for the Internet Connectivity
    public boolean isConnectingToInternet(){
        ConnectivityManager connectivity = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }

        }
        return false;
    }

    
}
